import ImageGallery from './components/ImageGallery/ImageGallery';

function App() {
  return (
    <ImageGallery/>
  );
}

export default App;
